indent the code in ui file, now is most readable.
ui and mnx files have comments, please check it.